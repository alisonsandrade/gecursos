import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the CursoServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class CursoServiceProvider {

  constructor(public http: HttpClient) {
    console.log('Hello CursoServiceProvider Provider');
  }

  getCursos() {
    return this.http.get('assets/db/cursos.json');
  }

}
